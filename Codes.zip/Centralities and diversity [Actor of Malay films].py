#!/usr/bin/env python
# coding: utf-8

# ## Import related module

# In[1]:


import csv
import math
import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.patches as mpatches
from itertools import combinations
from operator import itemgetter
from collections import Counter
import collections
get_ipython().run_line_magic('matplotlib', 'inline')


# ## Read file

# In[2]:


index=pd.read_csv('Filmandactor.csv')
index.head()


# In[3]:


# make barplot
#order=index.sort_values('Debut year')
#index['Debut year'].value_counts().plot(kind='bar',figsize=(10,8))
plt.figure(figsize=(10, 5))
sns.countplot(index['Debut year'])
# set labels
plt.xticks(rotation=90)
plt.xlabel("Debut year", size=15)
plt.ylabel("Frequency", size=15)
plt.title("To see number of new actors by year", size=18)
plt.tight_layout()


# ## Calculate career year the actor has been in the industry

# In[4]:


def year(row):
    return 2020 - row['Debut year']

index['Career year'] = index.apply(year, axis=1)
index.head()


# ## Calculate total films for each actors

# In[5]:


new_index = index.Actor.value_counts().rename_axis('Actor').to_frame('Total film')
index = pd.merge(index,new_index,on ='Actor',how ='outer') #merge output column into original data frame
index


# ## Calculate total genre for each actor

# In[6]:


def gen(series):
    _, cnt = np.unique(series, return_counts=True)
    b=cnt
    return len(b)

genre = index.groupby('Actor').agg({'Genre': gen})
df = pd.DataFrame (genre, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'Total Genre'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index


# ## Race and gender of actors

# In[7]:


# sorting by first name
race=index.copy()
race.sort_values("Actor", inplace = True)
# dropping ALL duplicate actor's name
race.drop_duplicates(subset ="Actor",keep = "first", inplace = True)
freq=race.groupby(['Races'])['Gender'].value_counts()
freq.plot(kind='bar', title='Actors of Malay Films', ylabel='Frequency',
         xlabel='Race and Gender', figsize=(8, 4))
plt.savefig('Figure A2.jpg',dpi=500,bbox_inches = 'tight')


# ## Exclude actors with one film

# In[8]:


act1=index[index['Total film']==1]
fig, ax = plt.subplots(figsize=(8, 3))
act1["Career year"].plot(kind = 'hist',align='mid',bins=10000,width=0.5)
plt.xlabel("Career year per actor (CYA)")
plt.title(label="Frequency of actors with 1 film",loc="center")
plt.savefig('Figure A1.jpg',dpi=500,bbox_inches = 'tight')


# In[9]:


# remove rows by filtering
index.drop(index.loc[index['Total film']==1].index, inplace=True)
# display the dataframe
index.to_csv('Filmandactor_1.csv', index=False) #save to new file
index


# ## Define HHI*

# In[10]:


#Nan were replaced with 1, because denominator 0=(1-(1/1)) for actors that work in one film only
def nhhi(series):
    _, cnt = np.unique(series, return_counts=True)
    c = 1-(((np.square(cnt/cnt.sum()).sum())-(1/len(cnt)))/(1-(1/len(cnt))))
    if math.isnan(c):
        return 0
    else:
        return c

example = index.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
example


# ## Find HHI* for each year (cumulative films)

# ### HHI* 2020

# In[11]:


new_index = index.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
df = pd.DataFrame (new_index, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'HHI*_2020'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index


# ### HHI* 2019

# In[12]:


h19 = index[index['Year']<=2019]
new_h19 = h19.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
df = pd.DataFrame (new_h19, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'HHI*_2019'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index


# ### HHI* 2018

# In[13]:


h18 = index[index['Year']<=2018]
new_h18 = h18.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
df = pd.DataFrame (new_h18, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'HHI*_2018'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index


# ### HHI* 2017

# In[14]:


h17 = index[index['Year']<=2017]
new_h17 = h17.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
df = pd.DataFrame (new_h17, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'HHI*_2017'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index


# ### HHI* 2016

# In[15]:


h16 = index[index['Year']<=2016]
new_h16 = h16.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
df = pd.DataFrame (new_h16, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'HHI*_2016'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index


# ### HHI* 2015

# In[16]:


h15 = index[index['Year']==2015]
new_h15 = h15.groupby('Actor').agg({'Genre': nhhi})#group by actor and calculate their HHI* based on Genre
df = pd.DataFrame (new_h15, columns = ['Genre']) #save output into data frame in new column
index = pd.merge(index,df,on ='Actor',how ='outer') #merge output column into original data frame
index = index.rename({'Genre_x': 'Genre', 'Genre_y': 'HHI*_2015'}, axis=1) #rename header
index.sort_values("Actor", inplace = True)# sorting by first name
index.fillna(np.NaN)
index


# ## Frequency of HHI*

# In[17]:


index.drop_duplicates(subset ="Actor",keep = "first", inplace = True)
fig, ax = plt.subplots(figsize=(8, 3))
index["HHI*_2020"].plot(kind = 'hist',align='mid',bins=1000,width=0.02)
plt.xlabel("HHI*")
plt.title(label="Frequency of HHI*",loc="center")


# In[18]:


#index.loc[index['Actor'] == 'Pekin Ibrahim']
diversity = [] #create dictionary
for value in index["HHI*_2020"]:
    if value == 0:
        diversity.append("Non-diverse actors")
    else:
        diversity.append("Diverse actors")
       
index["Group"] = diversity #save dictionary into new column
index


# ## Career Year vs Total Films (colour = diversity) 

# ## Find first HHI*

# In[19]:


index['combined']=index['HHI*_2015'].astype(str)+','+index['HHI*_2016'].astype(str)+','+index['HHI*_2017'].astype(str)+','+index['HHI*_2018'].astype(str)+','+index['HHI*_2019'].astype(str)+','+index['HHI*_2020'].astype(str)
index['combined'] = [x.lstrip(',nan') for x in index['combined']]
new=index['combined'].str.split(',',n=2,expand=True)
# making separate first name column from new data frame
index["First HHI*"]= new[0]
# Dropping old Name columns
index.drop(columns =["combined"], inplace = True)
index['First HHI*']=pd.to_numeric(index['First HHI*'])
index['First HHI*']=index['First HHI*'].round(decimals = 4)
index


# ## First HHI* vs Final HHI*

# In[20]:


m1= index['First HHI*'].astype(float) > index['HHI*_2020']
m2= index['First HHI*'].astype(float) < index['HHI*_2020']
#m3= k['First value'].astype(float) == k['HHI*_2020']

index['Group Changes'] = np.select([m1, m2],
                    [ 'Changed', 'Changed'], 
                    default='Unchanged')


# In[21]:


chan = index[index['Group Changes']=='Changed']
uchan = index[index['Group Changes']=='Unchanged']


# In[22]:


u=uchan.groupby(['HHI*_2020', 'Total film'])
u


# In[74]:


fig = plt.figure(figsize=(10, 4))

plt.scatter(
    x=chan['HHI*_2020'],
    y=chan['First HHI*'],
    s=55,
    c=chan['Total film'],
    cmap="autumn",
    marker='*',
    alpha=0.7,
    label='Changed'
    )
plt.scatter(
    x=uchan['HHI*_2020'],
    y=uchan['First HHI*'],
    s=55,
    c=uchan['Total film'],
    cmap="autumn",
    marker='s',
    alpha=0.7,
    label='Unhanged'
    )

plt.title("NHHI(x) VS NHHI")
plt.xlabel("Genre diversity until 2020 of actor $\t{i}$ [NHHI]")
plt.ylabel("Genre diversity in first year of actor $\t{i}$ [NHHI($\t{x}$)]")

# Add colorbar, make sure to specify tick locations to match desired ticklabels
clb=plt.colorbar(ticks=[2,3.5,5])
clb.ax.set_yticklabels(['2', '8','16'])  # vertically oriented colorbar
clb.ax.set_ylabel('Number of films of actor $\t{i}$ [TFA]')
plt.legend(title="Group Changes NHHI",loc="upper left")
plt.savefig('Figure 7.jpg',dpi=500,bbox_inches = 'tight')
plt.show()
#index.to_csv('Example1.csv', index=False) #save to new file


# ## Actor network 

# ### Generated nodes and weighted edges from data 

# In[24]:


nod= index.loc[:,['Actor','Total film','Career year','Gender','Races','Debut year','HHI*_2020','Total Genre','Group']]
nod.to_csv('Actor_nodes.csv', index=False) #save to new file


# In[25]:


edges = pd.read_csv('Filmandactor_1.csv') #read csv file

def get_combinations(group):
    return pd.DataFrame([sorted(e) for e in list(combinations(group['Actor'].values, 2))], columns=['from', 'to'])

edges = edges.groupby('Film').apply(get_combinations) #get all 2-combinations of names within each group
edges = edges.groupby(['from', 'to']).size().to_frame('weight').reset_index() #group by the node names to obtain the weight
edges.to_csv('Actor_edges.csv', index=False) #save into different file
edges.head()


# ### Create network

# In[26]:


G=nx.Graph() #create blank network


# In[27]:


with open('Actor_edges.csv', 'r') as edgecsv: # Open the file
    edgereader = csv.reader(edgecsv) # Read the csv
    edges = [tuple(e) for e in edgereader][1:] # Retrieve the data

G.add_weighted_edges_from(edges) #add weighted edges into network


# In[28]:


with open('Actor_nodes.csv', 'r') as nodecsv: # Open the file
    nodereader = csv.reader(nodecsv) # Read the csv
    nodes = [n for n in nodereader][1:]# Retrieve the data 

node_names = [n[0] for n in nodes] # Get a list of only the node names
G.add_nodes_from(node_names) #add nodes into network


# In[29]:


#set node attribute
#Create blank dictionary
total_dict = {}
career_dict = {}
gender_dict = {}
races_dict = {}
debut_dict = {}
hhi_dict = {}
genre_dict = {}
group_dict = {}

#Loop through the list, one row at a time
for node in nodes: 
    total_dict[node[0]] = node[1]
    career_dict[node[0]] = node[2]
    gender_dict[node[0]] = node[3]
    races_dict[node[0]] = node[4]
    debut_dict[node[0]] = node[5]
    hhi_dict[node[0]] = node[6]
    genre_dict[node[0]] = node[7]
    group_dict[node[0]] = node[8]
    
#set nodes attribute in network
nx.set_node_attributes(G, total_dict, 'Total_Film')
nx.set_node_attributes(G, career_dict, 'Career')
nx.set_node_attributes(G, gender_dict, 'Gender')
nx.set_node_attributes(G, races_dict, 'Races')
nx.set_node_attributes(G, debut_dict, 'Debut_Year')
nx.set_node_attributes(G, hhi_dict, 'HHI*')
nx.set_node_attributes(G, genre_dict, 'Genre')
nx.set_node_attributes(G, group_dict, 'Group')


# ### Network Information 

# In[30]:


density = nx.density(G) #calculate network density
print("Network density:", density)
print(nx.info(G))


# In[31]:


# If the Graph has more than one component, this will return False:
print("Network is connected:",nx.is_connected(G))
# Next, use nx.connected_components to get the list of components,
# then use the max() command to find the largest one:
components = nx.connected_components(G)
largest_component = max(components, key=len)
# Create a "subgraph" of just the largest component
# Then calculate the diameter of the subgraph
subgraph = G.subgraph(largest_component)
diameter = nx.diameter(subgraph)
print("Network diameter of largest component:", diameter)
print("Triadic closure:", nx.transitivity(G))#transitivity
print ("Average shortest path:", nx.average_shortest_path_length(subgraph))
print ("Average clustering:", nx.average_clustering(G))


# In[32]:


#G(N,<k>,p)=G(243,15,15/242)
random=nx.watts_strogatz_graph(243,15,15/242)


# In[33]:


def random_networks_generator(N, k, p, num_networks=1, directed=False):
    Graph_list = []
    densities = []
    trans = []
    clusterings = []
    avgpath = []
    for _ in range(num_networks):
        G = nx.watts_strogatz_graph(N,k,p)
        D = nx.density(G)
        T = nx.transitivity(G)
        APL = nx.average_shortest_path_length(G)
        C = nx.average_clustering(G)
        Graph_list.append(G)
        densities.append(D)
        trans.append(T)
        avgpath.append(APL)
        clusterings.append(C)
    return densities, trans, avgpath, clusterings 

results = random_networks_generator(243, 15, 15/242, 1000, directed=False)
for x in results:
    #print("10 list:",x)
    print("Average 1000 iteration:",sum(x)/len(x))


# In[34]:


print("Network density:", nx.density(random))
print(nx.info(random))
print("Triadic closure:", nx.transitivity(random))#transitivity
print ("Average shortest path:", nx.average_shortest_path_length(random))
print ("Average clustering:", nx.average_clustering(random))


# In[35]:


#G(N,p)=G(243,15/242)
random_renyi=nx.erdos_renyi_graph(243,15/242)
print("Network density:", nx.density(random_renyi))
print(nx.info(random_renyi))
print("Triadic closure:", nx.transitivity(random_renyi))#transitivity
print ("Average shortest path:", nx.average_shortest_path_length(random_renyi))
print ("Average clustering:", nx.average_clustering(random_renyi))


# ## Degree Distribution

# In[36]:


# Degree Distribution
degrees = pd.DataFrame(G.degree(), columns=['Node','Degree'])
sns.distplot(a=degrees['Degree'],kde=False)
plt.title('Degree distribution')
plt.ylabel('Number of nodes')


# In[37]:


#Degree distribution in log scale
degrees = dict(G.degree())
degree_values = sorted(set(degrees.values()))
histogram = [list(degrees.values()).count(i)/float(nx.number_of_nodes(G)) for i in degree_values]
plt.figure()
plt.plot(degree_values, histogram, 'o')
plt.title('Degree distribution in log scale')
plt.xlabel('Degree, k')
plt.ylabel('Fraction of nodes, p(k)')
plt.xscale('log')
plt.yscale('log')
plt.show()


# In[38]:


#Fit power law
import powerlaw
degree_sequence = sorted([d for n, d in G.degree()], reverse=True) # used for degree distribution and powerlaw test
#Power laws are probability distributions with the form:p(x)∝x−α
fit = powerlaw.Fit(degree_sequence,xmin=1) 
fig2 = fit.plot_pdf(color='blue', linewidth=2, label='Empiricial data')
fit.power_law.plot_pdf(ax=fig2,color='red', linestyle='--', label='Power law fit') #powerlaw
plt.ylabel('P(>k)')
plt.xlabel('Degree, k')
plt.title('Degree distribution fit to power law')
plt.legend()


# ### Draw network with networkx

# In[39]:


pos=nx.spring_layout(G,scale=2) #spring layout
plt.figure(figsize =(20, 20)) #figure size
nx.draw(G,pos,
            with_labels=False,
            node_size=100, 
            node_color="blue", 
            node_shape="o",
            font_size=8,
            font_color="black",
            linewidths=1.5,
            width=4,
            edge_color="grey",)


# ## Calculate centralities

# In[40]:


betweenness_dict = nx.betweenness_centrality(G) # Run betweenness centrality
eigenvector_dict = nx.eigenvector_centrality(G) # Run eigenvector centrality
closeness_dict = nx.closeness_centrality(G) # Run closeness centrality
degree_dict = nx.degree_centrality(G) # Run degree centrality
ndegree_dict = {n: d for n, d in G.degree()} # Run degree

# Assign each to an attribute in your network
nx.set_node_attributes(G, betweenness_dict, 'betweenness')
nx.set_node_attributes(G, eigenvector_dict, 'eigenvector')
nx.set_node_attributes(G, closeness_dict, 'closeness')
nx.set_node_attributes(G, degree_dict, 'degree')
nx.set_node_attributes(G, ndegree_dict, 'ndegree')


# ## Average shortest path for every actor

# In[41]:


def shortest_path(G):
    shortestpl_dict = {}
    for node in G.nodes():
        shortestpl_dict[node] = np.average(
            list(nx.shortest_path_length(G, weight=None, source=node).values()))
    return shortestpl_dict


# In[42]:


avg_dict = shortest_path(subgraph)
nx.set_node_attributes(G, avg_dict, 'avg')


# In[43]:


att = pd.DataFrame([i[1] for i in G.nodes(data=True)], index=[i[0] for i in G.nodes(data=True)])
#att = att.astype({'Total_Film':'float64', 'Year_Career':'float64', 'Debut_Year':'float64', 'HHI*':'float64'})
att.to_csv('Actor_centralities.csv', index=True) #save to new file
att = pd.read_csv('Actor_centralities.csv')
att = att.rename(columns={att.columns[0]: 'Actor'})
att.head()


# ## Description of attributes

# In[44]:


describe = att.describe()
print(describe)


# ## Top 10 Average shortest path

# In[45]:


lowest_avg_shortest_path = att.sort_values(by="avg",ascending=True)
lowest_avg_shortest_path.head(10)


# ## Candidate for Kevin Bacon

# In[46]:


candidate = [] #create dictionary
for value in att["avg"]:
    if value < 2:
        candidate.append("Candidate")
    else:
        candidate.append("Actors")
       
att["candidate"] = candidate #save dictionary into new column
att


# ## Top 10 Degree centrality

# In[47]:


val=att.sort_values(by="degree",ascending=False)
print("Mean: ", val["degree"].mean())
val.head(10)


# ## Top 10 Betweenness Centrality

# In[48]:


val1=att.sort_values(by="betweenness",ascending=False)
print("Mean: ", val1["betweenness"].mean())
val1.head(10)


# ## Plot TFA vs average shortest path and centralities

# In[49]:


cand = att[att['candidate']=='Candidate']
ucand = att[att['candidate']=='Actors']


# In[50]:


#define function to calculate r-squared
def polyfit(x, y, degree):
    results = {}
    coeffs = np.polyfit(x, y, degree)
    p = np.poly1d(coeffs)
    #calculate r-squared
    yhat = p(x)
    ybar = np.sum(y)/len(y)
    ssreg = np.sum((yhat-ybar)**2)
    sstot = np.sum((y - ybar)**2)
    results= ssreg / sstot

    return results


# In[66]:


fig = plt.figure(figsize=(8, 4))

plt.scatter(
    x=cand['avg'],
    y=cand['Total_Film'],
    s=50,
    c="green",
    marker='D',
    alpha=0.7,
    label='Candidate'
    )
plt.scatter(
    x=ucand['avg'],
    y=ucand['Total_Film'],
    s=40,
    cmap="blue",
    marker='o',
    alpha=0.7,
    label='Others'
    )

plt.text(cand.avg[cand.Actor=='Pekin Ibrahim'],cand.Total_Film[cand.Actor=='Pekin Ibrahim'],"A-Pekin Ibrahim", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.avg[cand.Actor=='Soffi Jikan'],cand.Total_Film[cand.Actor=='Soffi Jikan']+0.25,"B-Soffi Jikan", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.avg[cand.Actor=='Namron'],cand.Total_Film[cand.Actor=='Namron'],"C-Namron", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.avg[cand.Actor=='Remy Ishak'],cand.Total_Film[cand.Actor=='Remy Ishak']-0.2,"D-Remy Ishak", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.avg[cand.Actor=='Faizal Hussein'],cand.Total_Film[cand.Actor=='Faizal Hussein'],"E-Faizal Hussein", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.avg[cand.Actor=='Nora Danish'],cand.Total_Film[cand.Actor=='Nora Danish'],"F-Nora Danish ,", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.avg[cand.Actor=="Dato' Jalaluddin Hassan"]+0.4,cand.Total_Film[att.Actor=="Dato' Jalaluddin Hassan"],"G-Dato' Jalaluddin Hassan", 
 fontdict=dict(color='black', alpha=1, size=9))

plt.xlabel("Average shortest path of actor $\t{i}$")
plt.ylabel("Number of films of actor $\t{i}$ (TFA)")
plt.title(label="Average shortest path VS TFA",loc="center")

plt.legend(title="Kevin Bacon candidate",loc="upper right")
plt.savefig('Figure 1.jpg',dpi=500,bbox_inches = 'tight')
plt.show()


# In[67]:


fig, ax = plt.subplots(figsize=(8, 4))

plt.scatter(
    x=cand['degree'],
    y=cand['Total_Film'],
    s=50,
    c="green",
    marker='D',
    alpha=0.7,
    label='Candidate'
    )
plt.scatter(
    x=ucand['degree'],
    y=ucand['Total_Film'],
    s=40,
    cmap="blue",
    marker='o',
    alpha=0.7,
    label='Others'
    )
plt.xlabel("Degree centrality of actor $\t{i}$ (DC) ")
plt.ylabel("Number of films of actor $\t{i}$ (TFA)")
plt.title(label="DC VS TFA",loc="center")

plt.text(cand.degree[cand.Actor=='Pekin Ibrahim'],cand.Total_Film[att.Actor=='Pekin Ibrahim'],"A-Pekin Ibrahim", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.degree[cand.Actor=='Soffi Jikan'],cand.Total_Film[att.Actor=='Soffi Jikan']+0.25,"B-Soffi Jikan", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.degree[cand.Actor=='Namron'],cand.Total_Film[att.Actor=='Namron'],"C-Namron", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.degree[cand.Actor=='Remy Ishak'],cand.Total_Film[att.Actor=='Remy Ishak']-0.2,"D-Remy Ishak", 
 fontdict=dict(color='black', alpha=1, size=9))

# Fit linear regression via least squares with numpy.polyfit
# It returns an slope (b) and intercept (a)
# deg=1 means linear fit (i.e. polynomial of degree 1)
b, a = np.polyfit(att['degree'], att['Total_Film'], deg=1)
# Create sequence of 100 numbers from 0 to 0.21 
xseq = np.linspace(0, 0.21, num=100)
r='%.4f' %polyfit(att['degree'], att['Total_Film'], 1)
# Plot regression line
ax.plot(xseq, a + b * xseq, color="k",  lw=1.5, label="Linear Fit")
ax.text(0, 11, '$R^2$: '+r, fontsize = 10)

# plot the legend
plt.legend(loc="upper left")
plt.savefig('Figure 3.jpg',dpi=500,bbox_inches = 'tight')
plt.show()


# In[68]:


fig, ax = plt.subplots(figsize=(8, 4))

plt.scatter(
    x=cand['betweenness'],
    y=cand['Total_Film'],
    s=50,
    c="green",
    marker='D',
    alpha=0.7,
    label='Candidate'
    )
plt.scatter(
    x=ucand['betweenness'],
    y=ucand['Total_Film'],
    s=40,
    cmap="blue",
    marker='o',
    alpha=0.7,
    label='Others'
    )
plt.xlabel("Betweenness centrality of actor $\t{i}$ (BC) ")
plt.ylabel("Number of films of actor $\t{i}$ (TFA)")
plt.title(label="BC VS TFA",loc="center")

plt.text(cand.betweenness[cand.Actor=='Pekin Ibrahim'],cand.Total_Film[cand.Actor=='Pekin Ibrahim'],"A-Pekin Ibrahim", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.betweenness[cand.Actor=='Soffi Jikan'],cand.Total_Film[cand.Actor=='Soffi Jikan']+0.25,"B-Soffi Jikan", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.betweenness[cand.Actor=='Namron'],cand.Total_Film[cand.Actor=='Namron'],"C-Namron", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.betweenness[cand.Actor=='Remy Ishak'],cand.Total_Film[cand.Actor=='Remy Ishak']-0.2,"D-Remy Ishak", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(cand.betweenness[cand.Actor=="Dato' Jalaluddin Hassan"],cand.Total_Film[cand.Actor=="Dato' Jalaluddin Hassan"],"G-Dato' Jalaluddin Hassan", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(ucand.betweenness[ucand.Actor=='Nur Fathiah Diaz'],ucand.Total_Film[ucand.Actor=='Nur Fathiah Diaz'],"Nur Fathiah Diaz", 
 fontdict=dict(color='black', alpha=1, size=9))
plt.text(ucand.betweenness[ucand.Actor=='Fadlan Hazim'],ucand.Total_Film[ucand.Actor=='Fadlan Hazim'],"Fadlan Hazim", 
 fontdict=dict(color='black', alpha=1, size=9))

#polynomial fit with degree = 2
model = np.poly1d(np.polyfit(att['betweenness'], att['Total_Film'], 2))
#add fitted polynomial line to scatterplot
polyline = np.linspace(0, 0.053, 50)
ax.plot(polyline, model(polyline), color="k",label="Quadratic Fit")
r='%.4f' %polyfit(att['betweenness'], att['Total_Film'], 2)
ax.text(0, 11, '$R^2$: '+r, fontsize = 10)

# plot the legend
plt.legend(loc="upper left")
plt.savefig('Figure 5.jpg',dpi=500,bbox_inches = 'tight')
plt.show()


# In[78]:


fig, ax = plt.subplots(figsize=(8, 4))

plt.scatter(
    x=cand['closeness'],
    y=cand['Total_Film'],
    s=50,
    c="green",
    marker='D',
    alpha=0.7,
    label='Candidate'
    )
plt.scatter(
    x=ucand['closeness'],
    y=ucand['Total_Film'],
    s=40,
    cmap="blue",
    marker='o',
    alpha=0.7,
    label='Others'
    )
plt.xlabel("Closeness centrality of actor $\t{i}$")
plt.ylabel("Number of films of actor $\t{i}$ (TFA)")
plt.title(label="Closeness centrality VS TFA",loc="center")

# plot the legend
plt.legend(loc="upper left")
plt.savefig('Figure S2.jpg',dpi=500,bbox_inches = 'tight')
plt.show()


# In[77]:


fig, ax = plt.subplots(figsize=(8, 4))

plt.scatter(
    x=cand['eigenvector'],
    y=cand['Total_Film'],
    s=50,
    c="green",
    marker='D',
    alpha=0.7,
    label='Candidate'
    )
plt.scatter(
    x=ucand['eigenvector'],
    y=ucand['Total_Film'],
    s=40,
    cmap="blue",
    marker='o',
    alpha=0.7,
    label='Others'
    )
plt.xlabel("Eigenvector centrality of actor $\t{i}$ ")
plt.ylabel("Number of films of actor $\t{i}$ (TFA)")
plt.title(label="Eigenvector centrality VS TFA",loc="center")

# plot the legend
plt.legend(loc="upper left")
plt.savefig('Figure S4.jpg',dpi=500,bbox_inches = 'tight')
plt.show()


# ### Save network to Gephi

# In[56]:


nx.write_gexf(G, 'actor_network.gexf')

